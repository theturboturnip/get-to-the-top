LICENSE
======
You are free to use Octave (the "sound set") or any part thereof (the "sounds") in any personal, open-source or commercial work without obligation of payment (monetary or otherwise) or attribution. Do not sell the sound set, host the sound set or rent the sound set (either in existing or modified form).

While attribution is optional, it is always appreciated.

Intellectual property rights are not transferred with the download of the sounds.

EXCEPT TO THE EXTENT REQUIRED BY APPLICABLE LAW, IN NO EVENT WILL FRED SHOWELL BE LIABLE TO YOU ON ANY LEGAL THEORY FOR ANY SPECIAL, INCIDENTAL, CONSEQUENTIAL, PUNITIVE, EXEMPLARY OR TEARJERKING DAMAGES ARISING OUT OF THE USE OF THE SOUNDS, EVEN IF LICENSOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.