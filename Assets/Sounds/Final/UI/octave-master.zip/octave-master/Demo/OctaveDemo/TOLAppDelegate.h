//
//  TOLAppDelegate.h
//  OctaveTest
//
//  Created by Lars Anderson on 1/31/13.
//  Copyright (c) 2013 @theonlylars. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TOLViewController;

@interface TOLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TOLViewController *viewController;

@end
