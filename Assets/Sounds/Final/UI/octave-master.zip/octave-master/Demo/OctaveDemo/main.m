//
//  main.m
//  OctaveTest
//
//  Created by Lars Anderson on 1/31/13.
//  Copyright (c) 2013 @theonlylars. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TOLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TOLAppDelegate class]));
    }
}
